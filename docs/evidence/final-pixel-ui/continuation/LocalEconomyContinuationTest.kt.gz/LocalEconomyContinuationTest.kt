package io.drivegrowth.app.simulation

import io.drivegrowth.app.mainNavigation
import io.drivegrowth.app.openMainPage
import io.drivegrowth.app.showSimulationControls
import io.drivegrowth.app.host.HostPage
import android.os.SystemClock
import android.test.ActivityInstrumentationTestCase2
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import io.drivegrowth.app.R
import io.drivegrowth.app.data.*
import io.drivegrowth.app.host.*
import io.drivegrowth.core.contract.*
import io.drivegrowth.core.delivery.DeliveryOffer
import android.util.Log
import io.drivegrowth.app.host.progression.progressKey
import io.drivegrowth.core.quest.questPeriod
import io.drivegrowth.core.garage.CollectionKey
import io.drivegrowth.core.rental.*
import java.time.Instant
import java.time.ZoneId

/** 시연 런처의 실제 기존 UI/공개 명령/SQLite. 입력·도착은 명시 SIMULATION, SDK 실행 시험이 아니다. */
@Suppress("DEPRECATION")
class LocalEconomyContinuationTest : ActivityInstrumentationTestCase2<UnifiedSimulationActivity>(UnifiedSimulationActivity::class.java) {
    private val context get() = instrumentation.targetContext
    private fun <T> ok(result: ContractResult<T>): T { assertTrue(result.toString(), result is ContractResult.Success); return (result as ContractResult.Success).value }
    private fun tree(v: View): List<View> = listOf(v) + if (v is ViewGroup) (0 until v.childCount).flatMap { tree(v.getChildAt(it)) } else emptyList()
    private fun awaitUi(a: UnifiedSimulationActivity, label: String, check: () -> Boolean) {
        val end=SystemClock.uptimeMillis()+90_000;var passed=false
        while (!passed && SystemClock.uptimeMillis()<end) {
            instrumentation.runOnMainSync { passed=check() }
            if (!passed) SystemClock.sleep(50)
        }
        assertTrue(label,passed)
    }
    private fun click(a: UnifiedSimulationActivity, tag: Any) {
        awaitUi(a, "active button $tag") {
            a.window.decorView.findViewWithTag<Button>(tag)
                ?.takeIf { it.isShown && it.isEnabled && it.isAttachedToWindow }?.performClick() == true
        }
    }
    private fun factory(): GameSessionFactory {
        val clock={ val p=context.getSharedPreferences("unified-simulation-v1",0);SimulationTimeline(p.getLong("elapsed",0),p.getInt("stage",0)).clock.epoch.value }
        return GameSessionFactory(context,mapOf(InputSource.SIMULATION to "unified-simulation.db"),InputSource.SIMULATION,{
            when (val r=AssetTrialDefinitionProvider(context.assets).load()) {
                is ContractResult.Failure->r
                is ContractResult.Success->r.value.questDefinitions(ZoneId.of("UTC"))
            }
        },clock)
    }
    private fun <T> read(action:(GameSession)->T):T = ok(factory().open()).use(action)
    private fun awaitStored(label:String,check:()->Boolean) {
        val end=SystemClock.uptimeMillis()+90_000
        while (SystemClock.uptimeMillis()<end) { if(check())return;SystemClock.sleep(50) }
        fail(label)
    }
    private val prefs get() = context.getSharedPreferences("unified-simulation-v1",0)
    private fun timeline() = SimulationTimeline(prefs.getLong("elapsed",0), prefs.getInt("stage",0))
    private fun page(a: UnifiedSimulationActivity, page: HostPage) {
        awaitUi(a, "page $page") {
            val button = a.window.decorView.findViewWithTag<Button>("host:page:${page.name}") ?: return@awaitUi false
            if (!button.isShown || !button.isEnabled) return@awaitUi false
            if (button.isSelected) return@awaitUi true
            button.performClick()
            false
        }
    }
    private fun drive(a: UnifiedSimulationActivity) {
        val before = timeline().elapsedMs
        instrumentation.runOnMainSync { a.window.decorView.showSimulationControls() }
        click(a, "simulation:start")
        awaitUi(a, "simulated drive ends") {
            timeline().elapsedMs > before && timeline().terminal && a.window.decorView.mainNavigation()?.isEnabled == true
        }
    }
    private fun slot() = read { g -> ok(g.store.hostCommands.load(g.identity.profileId)) }
    private fun awaitClear() = awaitStored("common slot clears") { slot() == null }
    private fun rows() = read { g -> ok(g.store.listUnviewedSettlements()) }
    private fun balance() = read { g -> ok(g.store.balance()) }
    private fun owned() = read { g -> ok(g.store.listOwnedVehicles()) }
    private fun note(stage: String, detail: String) {
        Log.i("LocalEconomyContinuation", "$stage profile=${read { it.identity.profileId.value }} $detail")
    }

    fun testOneIsolatedSimulationProfileFreeTicketPurchaseFacilityAndQuest() {
        assertEquals("io.drivegrowth.verify.e2e28continuation", context.packageName)
        for (name in listOf("unified-simulation.db", "game-ledger-vehicle.db", "game-ledger-simulation.db"))
            assertFalse("fresh isolated database: $name", context.getDatabasePath(name).exists())
        assertFalse(prefs.contains("stage"))
        val a = activity
        for (tag in listOf(R.string.onboarding_start, VehicleId("hyundai_casper"), R.string.onboarding_review,
            R.string.onboarding_confirm, R.string.onboarding_to_shop)) click(a, tag)
        val identity = read { it.identity }
        assertEquals(InputSource.SIMULATION, identity.source)
        assertEquals(GameMoney(1_000), balance())
        page(a, HostPage.HOME)
        drive(a)
        awaitStored("first rental ticket") {
            read { ok(it.store.readFirstRentalGift(identity.profileId)).progress.freeTickets == 1L }
        }
        val beforeFree = balance()
        page(a, HostPage.GACHA)
        click(a, "gacha:option:free")
        assertEquals(beforeFree, balance())
        click(a, "gacha:confirm")
        click(a, "gacha:garage")
        awaitClear()
        val free = rows().single { it.changedVehicle?.acquisitionSource == VehicleAcquisitionSource.GACHA }
        assertEquals(InputSource.SIMULATION, free.transaction.source)
        assertNull(free.transaction.money)
        assertEquals(beforeFree, free.balance)
        assertEquals(GameMoney(0), free.changedVehicle?.acquisitionCost)
        assertEquals(2, owned().size)
        assertEquals(0L, read { ok(it.store.readFirstRentalGift(identity.profileId)).progress.freeTickets })
        note("FREE", "request=${free.transaction.requestId.value} balance=${free.balance.units} owned=2")

        read { g ->
            val rule = ok(g.content).ruleVersion
            ok(g.store.commitGameChange(GameChange(RequestId("e2e28-fixture-credit"), TransactionKind.GARAGE,
                identity.source, rule, MoneyChange(MoneyDirection.CREDIT, GameMoney(10_000)))))
        }
        val purchaseBefore = balance()
        page(a, HostPage.DELIVERY)
        click(a, "simulation:destination")
        val day = Instant.ofEpochMilli(timeline().clock.epoch.value).atZone(ZoneId.of("UTC")).toLocalDate()
        var offer: DeliveryOffer.Purchase? = null
        awaitStored("stored affordable purchase") {
            offer = read { g -> ok(g.store.delivery.lists(day)).flatMap { it.offers }.filterIsInstance<DeliveryOffer.Purchase>()
                .firstOrNull { it.price.units <= purchaseBefore.units - 500 } }
            offer != null
        }
        val purchase = checkNotNull(offer)
        awaitStored("discovery persisted") { read { CollectionKey(purchase.vehicleId,purchase.rarity) in ok(it.store.discoveredVehicles()) } }
        click(a, "delivery:offer:${purchase.id.value}")
        click(a, "delivery:confirm")
        awaitStored("purchase payment committed") { read { ok(it.store.delivery.inProgress()) != null } }
        val route = read { checkNotNull(ok(it.store.delivery.inProgress())) }
        val payment = rows().single { it.transaction.requestId == route.active.requestId }
        assertEquals(MoneyChange(MoneyDirection.DEBIT, purchase.price), payment.transaction.money)
        assertEquals(GameMoney(purchaseBefore.units - purchase.price.units), payment.balance)
        assertEquals(2, owned().size)
        click(a, "delivery:acknowledge")
        awaitClear()
        drive(a)
        awaitStored("matching purchase arrival") { read { ok(it.store.delivery.arrivalResult(route.active.requestId)) != null } }
        val arrival = read { checkNotNull(ok(it.store.delivery.arrivalResult(route.active.requestId))) }
        val delivered = checkNotNull(arrival.settlement?.changedVehicle)
        assertNull(arrival.settlement?.transaction?.money)
        assertEquals(purchase.vehicleId, delivered.vehicleId)
        assertEquals(purchase.rarity, delivered.rarity)
        assertEquals(purchase.price, delivered.acquisitionCost)
        assertEquals(VehicleAcquisitionSource.PURCHASE_DELIVERY, delivered.acquisitionSource)
        assertEquals(3, owned().size)
        assertEquals(route.route.value, prefs.getString("arrivalRoute", null))
        click(a, "delivery:acknowledge")
        awaitClear()
        note("DELIVERED", "request=${route.active.requestId.value} price=${purchase.price.units} owned=3")

        // 독립 시험 준비. 구매 탁송은 같은 프로필에 보존하고, 시설 해금에 필요한 조건만 마련한다.
        read { g ->
            val store = g.store
            val definition = ok(store.trialDefinitions.load())
            val rental = ok(definition.rentalVisitDefinition())
            val catalog = ok(g.content).catalog
            val first = ok(store.listOwnedVehicles()).first()
            repeat(3) { index ->
                val start = timeline().clock.epoch.value + (index + 1) * 4_500_000L
                val id = RequestId("e2e28-fixture-rental-$index")
                val terms = RentalTerms(rental.rules, SimulatedCustomer(30, 48), 99, EpochMillis(start),
                    15, rental.fuelBonus, rental.rounding, false)
                ok(store.rental.assign(RentalRequest(id, first.vehicleId, 1), catalog, rental.categories, rental.rates, terms))
                ok(store.rental.account(id, terms.start, EpochMillis(start + 3_600_000L), null))
                ok(store.rental.settle(id))
                ok(store.rental.finishReturn(id, EpochMillis(start + 4_500_000L)))
            }
            ok(store.rental.expand(RequestId("e2e28-fixture-expand"),
                ok(AssetShopExpansionProvider(context.assets).load()).offers.first()))
            repeat(2) { index ->
                val filler = first.copy(ownedVehicleId = OwnedVehicleId("e2e28-fixture-car-$index"), revision = Revision(0),
                    acquisitionSource = VehicleAcquisitionSource.GACHA)
                ok(store.commitGameChange(GameChange(RequestId("e2e28-fixture-add-$index"), TransactionKind.GARAGE,
                    identity.source, definition.rules, vehicle = VehicleWrite.Add(filler))))
            }
            assertEquals(5, ok(store.listOwnedVehicles()).size)
            assertTrue(ok(store.rental.shop()).facilities.isEmpty())
        }
        val beforeFacility = balance()
        page(a, HostPage.HOME)
        click(a, "host:refresh")
        awaitUi(a, "confirmed current fuel preview") {
            val root = a.window.decorView
            val shop = tree(root).filterIsInstance<io.drivegrowth.app.ui.shop.ShopView>().singleOrNull()
                ?: return@awaitUi false
            val selected = shop.uiState.selection?.option?.command
                as? io.drivegrowth.app.ui.shop.ShopCommand.BuyFacility
            val confirm = root.findViewWithTag<Button>("shop:confirm")
            if (selected?.offer?.facility == Facility.FUEL_STATION && confirm?.isEnabled == true && confirm.isShown)
                return@awaitUi confirm.performClick()
            root.findViewWithTag<Button>("shop:preview:facility-FUEL_STATION")
                ?.takeIf { it.isShown && it.isEnabled && it.isAttachedToWindow }?.performClick()
            false
        }
        awaitStored("facility committed") { read { Facility.FUEL_STATION in ok(it.store.rental.shop()).facilities } }
        val facility = checkNotNull(slot())
        val facilityCommand = facility.command as HostCheckpointCommand.FacilityPurchase
        assertEquals(HostCheckpointPhase.STARTED, facility.phase)
        assertEquals(GameMoney(500), facilityCommand.offer.price)
        assertEquals(GameMoney(beforeFacility.units - 500), balance())
        assertEquals(1, rows().count { it.transaction.requestId == facilityCommand.requestId })
        click(a, "facility:ack")
        awaitClear()
        note("FACILITY", "request=${facilityCommand.requestId.value} debit=500")

        val grant = rows().single { it.transaction.requestId == RequestId("initial-grant") }
        page(a, HostPage.RESULTS)
        click(a, "results:open:${grant.settlementId.value}")
        click(a, "results:mark:${grant.settlementId.value}")
        awaitStored("view persisted") { rows().none { it.settlementId == grant.settlementId } }
        val definitions = ok(ok(AssetTrialDefinitionProvider(context.assets).load()).questDefinitions(ZoneId.of("UTC")))
        val quest = definitions.definitions.single { it.id == "daily-result-viewed" }
        val period = questPeriod(quest.cadence, quest.zone, timeline().clock.epoch)
        val beforeQuest = balance()
        page(a, HostPage.PROGRESSION)
        click(a, progressKey(quest, period))
        click(a, "progress-claim")
        awaitStored("quest credit") { balance() == GameMoney(beforeQuest.units + quest.reward.units) }
        awaitClear()
        val claimed = rows().single { it.transaction.requestId.value.startsWith("quest/claim/") }
        assertEquals(InputSource.SIMULATION, claimed.transaction.source)
        assertEquals(MoneyChange(MoneyDirection.CREDIT, quest.reward), claimed.transaction.money)
        assertEquals(identity, read { it.identity })
        assertFalse(context.getDatabasePath("game-ledger-vehicle.db").exists())
        assertFalse(context.getDatabasePath("game-ledger-simulation.db").exists())
        note("QUEST", "request=${claimed.transaction.requestId.value} credit=${quest.reward.units} balance=${balance().units}")
    }
}
